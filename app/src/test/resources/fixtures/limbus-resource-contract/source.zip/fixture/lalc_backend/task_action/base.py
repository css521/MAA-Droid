@TaskExecution.register('empty')
def handler(): pass
@TaskExecution.register('click')
def handler(): pass
@TaskExecution.register('key')
def handler(): pass
@TaskExecution.register('swipe')
def handler(): pass
@TaskExecution.register('check_out_update')
def handler(): pass
